from flask import Flask, request, jsonify
from flask_cors import CORS
import openai
import os

app = Flask(__name__)
CORS(app)

openai.api_key = ""  

@app.route("/analyze", methods=["POST"])
def analyze_symptoms():
    data = request.json
    user_input = data.get("symptoms")

    if not user_input:
        return jsonify({"result": "Please provide symptoms to analyze."}), 400

    try:
        response = openai.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": "You are a health assistant."},
                {"role": "user", "content": f"The user describes the following symptoms: {user_input}. Based on this, suggest possible illnesses and what steps they should take (home care or see a doctor)."}
            ],
            max_tokens=150
        )
        result = response.choices[0].message.content.strip()
        return jsonify({"result": result})

    except Exception as e:
        print("ERROR:", e)
        return jsonify({"result": "Error processing your request."}), 500

if __name__ == "__main__":
    app.run(debug=True)

