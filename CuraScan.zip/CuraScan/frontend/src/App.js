import React, { useState } from 'react';
import './App.css';

function App() {
  const [symptoms, setSymptoms] = useState('');
  const [result, setResult] = useState('');
  const [showFollowUp, setShowFollowUp] = useState(false);
  const [actionTaken, setActionTaken] = useState('');
  const [feeling, setFeeling] = useState('');
  const [followUpResponse, setFollowUpResponse] = useState(null);

  const handleSubmit = async () => {
    if (!symptoms.trim()) {
      setResult('Please describe your symptoms.');
      return;
    }

    try {
      const response = await fetch('http://127.0.0.1:5000/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ symptoms }),
      });
      const data = await response.json();
      setResult(data.result);
      setShowFollowUp(true);
      setFollowUpResponse(null); // reset follow-up state if running again
    } catch (error) {
      setResult('Something went wrong. Please try again.');
    }
  };

  const handleFollowUpSubmit = () => {
    const advice =
      feeling === 'Same' || feeling === 'Worse'
        ? 'Since your condition hasn’t improved, you should consider seeing a healthcare provider.'
        : 'Glad to hear you’re feeling better! Keep monitoring your symptoms.';

    setFollowUpResponse({
      actionTaken,
      feeling,
      advice,
    });
  };

  return (
    <div className="app-container">
      <h1>CuraScan</h1>
      <p>Describe your symptoms below:</p>
      <textarea
        rows="6"
        value={symptoms}
        onChange={(e) => setSymptoms(e.target.value)}
        placeholder="e.g. I have a sore throat and fever..."
      />
      <button onClick={handleSubmit}>Analyze</button>

      {result && (
        <div className="result-box">
          {result}
        </div>
      )}

      {showFollowUp && (
        <div className="follow-up">
          <h3>Follow-up</h3>
          <p>What did you do after reading the advice?</p>
          <textarea
            rows="3"
            value={actionTaken}
            onChange={(e) => setActionTaken(e.target.value)}
            placeholder="e.g. Took medicine, drank water..."
          />
          <p>How do you feel now?</p>
          <select
            value={feeling}
            onChange={(e) => setFeeling(e.target.value)}
          >
            <option value="">Select an option</option>
            <option value="Better">Better</option>
            <option value="Same">Same</option>
            <option value="Worse">Worse</option>
          </select>
          <br />
          <button onClick={handleFollowUpSubmit} style={{ marginTop: '12px' }}>
            Submit Follow-up
          </button>
        </div>
      )}

      {followUpResponse && (
        <div className="result-box" style={{ marginTop: '20px', background: '#fff0f3' }}>
          <h4>Follow-up Summary</h4>
          <p><strong>What you did:</strong> {followUpResponse.actionTaken}</p>
          <p><strong>Current feeling:</strong> {followUpResponse.feeling}</p>
          <p><strong>Note:</strong> {followUpResponse.advice}</p>
        </div>
      )}
    </div>
  );
}

export default App;
