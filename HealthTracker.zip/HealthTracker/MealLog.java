import java.util.ArrayList;

public class MealLog {
    private ArrayList<String> meals;

    public MealLog() {
        meals = new ArrayList<>();
    }

    public void addMeal(String meal) {
        meals.add(meal);
    }

    public void printMeals() {
        System.out.println("Meals:");
        if (meals.isEmpty()) {
            System.out.println("  No meals logged.");
        } else {
            for (String m : meals) {
                System.out.println("  " + m);
            }
        }
    }
}
