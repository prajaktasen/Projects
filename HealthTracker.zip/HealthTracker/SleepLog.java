public class SleepLog {
    private int sleepHours;

    public void setSleepHours(int hours) {
        sleepHours = hours;
    }

    public int getSleepHours() {
        return sleepHours;
    }
}
