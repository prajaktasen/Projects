public class WaterLog {
    private double totalLiters;

    public void addWater(double liters) {
        totalLiters += liters;
    }

    public double getTotalLiters() {
        return totalLiters;
    }
}
