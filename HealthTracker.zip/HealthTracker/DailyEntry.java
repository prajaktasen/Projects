public class DailyEntry {
    private WaterLog waterLog;
    private ExerciseLog exerciseLog;
    private MealLog mealLog;
    private SleepLog sleepLog;

    public DailyEntry() {
        waterLog = new WaterLog();
        exerciseLog = new ExerciseLog();
        mealLog = new MealLog();
        sleepLog = new SleepLog();
    }

    public WaterLog getWaterLog() {
        return waterLog;
    }

    public ExerciseLog getExerciseLog() {
        return exerciseLog;
    }

    public MealLog getMealLog() {
        return mealLog;
    }

    public SleepLog getSleepLog() {
        return sleepLog;
    }

    public void printSummary() {
        System.out.println("\n--- Daily Summary ---");
        System.out.printf("Water intake: %.2f liters\n", waterLog.getTotalLiters());
        exerciseLog.printExercises();
        mealLog.printMeals();
        System.out.printf("Sleep: %d hours\n", sleepLog.getSleepHours());
    }
}
