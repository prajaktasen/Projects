import java.util.ArrayList;

public class ExerciseLog {
    private ArrayList<String> exercises;

    public ExerciseLog() {
        exercises = new ArrayList<>();
    }

    public void addExercise(String type, int minutes) {
        exercises.add(type + " - " + minutes + " mins");
    }

    public void printExercises() {
        System.out.println("Exercises:");
        if (exercises.isEmpty()) {
            System.out.println("  No exercise logged.");
        } else {
            for (String e : exercises) {
                System.out.println("  " + e);
            }
        }
    }
}
