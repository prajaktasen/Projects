import java.util.Scanner;

public class HealthTracker {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        DailyEntry today = new DailyEntry();

        while (true) {
            System.out.println("\n=== CURA HEALTH TRACKER ===");
            System.out.println("1. Log Water Intake");
            System.out.println("2. Log Exercise");
            System.out.println("3. Log Meal");
            System.out.println("4. Log Sleep");
            System.out.println("5. View Summary");
            System.out.println("6. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    System.out.print("Enter water intake (in liters): ");
                    double water = scanner.nextDouble();
                    scanner.nextLine();
                    today.getWaterLog().addWater(water);
                    break;
                case 2:
                    System.out.print("Enter exercise type: ");
                    String type = scanner.nextLine();
                    System.out.print("Enter duration (in minutes): ");
                    int minutes = scanner.nextInt();
                    scanner.nextLine();
                    today.getExerciseLog().addExercise(type, minutes);
                    break;
                case 3:
                    System.out.print("Enter meal description: ");
                    String meal = scanner.nextLine();
                    today.getMealLog().addMeal(meal);
                    break;
                case 4:
                    System.out.print("Enter hours of sleep: ");
                    int sleep = scanner.nextInt();
                    scanner.nextLine();
                    today.getSleepLog().setSleepHours(sleep);
                    break;
                case 5:
                    today.printSummary();
                    break;
                case 6:
                    System.out.println("Goodbye! Stay healthy.");
                    return;
                default:
                    System.out.println("Invalid choice. Try again.");
            }
        }
    }
}
