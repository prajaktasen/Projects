import java.util.Scanner;

public class BudgetApp {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        BudgetManager manager = new BudgetManager();
        String filename = "budget_data.txt";

        manager.loadFromFile(filename);

        while (true) {
            System.out.println("\n--- Personal Budgeting App ---");
            System.out.println("1. Add Income");
            System.out.println("2. Add Expense");
            System.out.println("3. View Balance");
            System.out.println("4. View Transactions");
            System.out.println("5. Save and Exit");
            System.out.print("Choose an option: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // clear newline

            switch (choice) {
                case 1:
                    System.out.print("Description: ");
                    String incomeDesc = scanner.nextLine();
                    System.out.print("Amount: ");
                    double incomeAmount = scanner.nextDouble();
                    manager.addTransaction(new Transaction("Income", incomeDesc, incomeAmount));
                    break;

                case 2:
                    System.out.print("Description: ");
                    String expenseDesc = scanner.nextLine();
                    System.out.print("Amount: ");
                    double expenseAmount = scanner.nextDouble();
                    manager.addTransaction(new Transaction("Expense", expenseDesc, expenseAmount));
                    break;

                case 3:
                    System.out.printf("Current Balance: $%.2f\n", manager.getBalance());
                    break;

                case 4:
                    System.out.println("Transaction History:");
                    manager.showTransactions();
                    break;

                case 5:
                    manager.saveToFile(filename);
                    System.out.println("Goodbye!");
                    return;

                default:
                    System.out.println("Invalid choice. Try again.");
            }
        }
    }
}

