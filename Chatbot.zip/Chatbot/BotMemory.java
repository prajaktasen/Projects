public class BotMemory {
    private String lastName = "";

    public void rememberName(String name) {
        this.lastName = name;
    }

    public String recallName() {
        return lastName;
    }

    public boolean knowsName() {
        return !lastName.isEmpty();
    }
}
