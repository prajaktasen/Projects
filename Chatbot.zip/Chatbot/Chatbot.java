import java.util.Scanner;

public class Chatbot {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ResponseBank responseBank = new ResponseBank();
        BotMemory memory = new BotMemory();

        System.out.println("Hello! I'm Chatty. How can I help you today? (type 'bye' to exit)");

        while (true) {
            System.out.print("You: ");
            String input = scanner.nextLine().toLowerCase().trim();

            if (input.equals("bye") || input.equals("exit")) {
                System.out.println("Goodbye! Talk to you later.");
                break;
            }

            String response = responseBank.getResponse(input, memory);
            System.out.println("🤖: " + response);
        }

        scanner.close();
    }
}
