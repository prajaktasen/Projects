import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class ResponseBank {

    public String getResponse(String input, BotMemory memory) {

        // Greetings
        if (input.matches(".*\\b(hello|hi|hey)\\b.*")) {
            return "Hi there! What’s on your mind?";
        }

        // Asking for bot's name
        if (input.contains("your name")) {
            return "I'm Chatty, your local AI assistant.";
        }

        // Asking for time
        if (input.contains("time")) {
            String time = LocalDateTime.now().format(DateTimeFormatter.ofPattern("hh:mm a"));
            return "The current time is " + time + ".";
        }

        // Asking for date
        if (input.contains("date")) {
            String date = LocalDateTime.now().format(DateTimeFormatter.ofPattern("MMMM dd, yyyy"));
            return "Today’s date is " + date + ".";
        }

        // Asking user's name
        if (input.contains("my name is")) {
            String[] parts = input.split("my name is");
            if (parts.length > 1) {
                String name = parts[1].trim().split(" ")[0];
                memory.rememberName(name);
                return "Nice to meet you, " + name + "!";
            }
        }

        if (input.contains("what is my name") || input.contains("do you know my name")) {
            if (memory.knowsName()) {
                return "Your name is " + memory.recallName() + "!";
            } else {
                return "I don’t think you told me your name yet.";
            }
        }

        // Thanks
        if (input.contains("thank")) {
            return "You're welcome!";
        }

        // Default response
        return "I'm not sure how to respond to that. Can you rephrase?";
    }
}
