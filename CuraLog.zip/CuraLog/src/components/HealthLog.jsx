import React, { useState, useEffect } from 'react';
import './HealthLog.css';
import { useNavigate } from 'react-router-dom';

function HealthLog() {
  const [entry, setEntry] = useState('');
  const [logs, setLogs] = useState([]);
  const navigate = useNavigate();

  // Load from localStorage on mount
  useEffect(() => {
    const storedLogs = localStorage.getItem('healthLogs');
    if (storedLogs) {
      try {
        const parsed = JSON.parse(storedLogs);
        if (Array.isArray(parsed)) {
          setLogs(parsed);
        }
      } catch (e) {
        console.error('Failed to parse health logs:', e);
      }
    }
  }, []);

  // Save to localStorage on update
  useEffect(() => {
    localStorage.setItem('healthLogs', JSON.stringify(logs));
  }, [logs]);

  const handleLogEntry = () => {
    if (!entry.trim()) return;

    const newLog = {
      text: entry,
      timestamp: new Date().toLocaleString(),
    };

    // Use functional version of setLogs to avoid stale state
    setLogs(prevLogs => {
      const updated = [newLog, ...prevLogs];
      localStorage.setItem('healthLogs', JSON.stringify(updated)); // safe write here too
      return updated;
    });

    setEntry('');
  };

  return (
    <div className="healthlog-container">
      <button className="back-button" onClick={() => navigate('/dashboard')}>
        ← Return to Dashboard
      </button>

      <h2>Health Log</h2>
      <textarea
        value={entry}
        onChange={(e) => setEntry(e.target.value)}
        placeholder="How are you feeling today?"
        className="healthlog-input"
        rows="5"
      />
      <button onClick={handleLogEntry} className="log-button">Log Entry</button>

      <h3>Previous Entries</h3>
      <div className="log-list">
        {logs.map((log, index) => (
          <div key={index} className="log-entry">
            <div className="log-timestamp">{log.timestamp}</div>
            <div className="log-text">{log.text}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default HealthLog;
