import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './CreateAccount.css';

function CreateAccount() {
  const navigate = useNavigate();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [children, setChildren] = useState('');
  const [spouse, setSpouse] = useState('');
  const [caretaker, setCaretaker] = useState('');
  const [location, setLocation] = useState('');
  const [message, setMessage] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();

    let storedUsers = localStorage.getItem('users');
    let users = [];
    try {
      users = storedUsers ? JSON.parse(storedUsers) : [];
      if (!Array.isArray(users)) users = [];
    } catch {
      users = [];
    }

    const existingUser = users.find((user) => user.email === email);

    if (existingUser) {
      setMessage('This email already exists. Log in instead?');
    } else {
      const newUser = { name, email, password, children, spouse, caretaker, location };
      users.push(newUser);
      localStorage.setItem('users', JSON.stringify(users));
      localStorage.setItem('currentUser', JSON.stringify(newUser)); // Store for dashboard
      navigate('/dashboard');
    }
  };

  return (
    <div className="create-account-container">
      <h2>Create Account</h2>
      <form onSubmit={handleSubmit} className="account-form">
        <label>
          Name
          <input
            type="text"
            placeholder="Enter your name"
            required
            value={name}
            onChange={(e) => setName(e.target.value)}
          />
        </label>
        <label>
          Email
          <input
            type="email"
            placeholder="Enter your email"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
        </label>
        <label>
          Password
          <input
            type="password"
            placeholder="Enter a password"
            required
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </label>
        <label>
          Children
          <input
            type="text"
            placeholder="Enter children's names or N/A"
            value={children}
            onChange={(e) => setChildren(e.target.value)}
          />
        </label>
        <label>
          Spouse
          <input
            type="text"
            placeholder="Enter spouse name or N/A"
            value={spouse}
            onChange={(e) => setSpouse(e.target.value)}
          />
        </label>
        <label>
          Caretaker
          <input
            type="text"
            placeholder="Enter caretaker name or N/A"
            value={caretaker}
            onChange={(e) => setCaretaker(e.target.value)}
          />
        </label>
        <label>
          Location
          <input
            type="text"
            placeholder="Enter your location"
            value={location}
            onChange={(e) => setLocation(e.target.value)}
          />
        </label>
        <button type="submit">Create Account</button>
      </form>

      {message && (
        <p style={{ color: '#ff9aa2', marginTop: '10px' }}>
          {message}{' '}
          <span className="link" onClick={() => navigate('/login')}>
            Log In
          </span>
        </p>
      )}

      <p>
        Already have an account?{' '}
        <span className="link" onClick={() => navigate('/login')}>
          Sign in
        </span>
      </p>
    </div>
  );
}

export default CreateAccount;
