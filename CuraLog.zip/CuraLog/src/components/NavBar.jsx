import React from 'react';
import { Link } from 'react-router-dom';

function NavBar() {
  return (
    <nav style={{ padding: '10px', backgroundColor: '#eee' }}>
      <Link to="/dashboard" style={{ marginRight: '15px' }}>Dashboard</Link>
      <Link to="/reminder" style={{ marginRight: '15px' }}>Reminders</Link>
      <Link to="/healthlog" style={{ marginRight: '15px' }}>Health Log</Link>
      <Link to="/login">Log Out</Link>
    </nav>
  );
}

export default NavBar;