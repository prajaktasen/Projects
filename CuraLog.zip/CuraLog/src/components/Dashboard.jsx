import React from 'react';
import { useNavigate } from 'react-router-dom';
import './Dashboard.css';

function Dashboard() {
  const navigate = useNavigate();

  const hour = new Date().getHours();
  const isDay = hour >= 6 && hour < 18;

  // Fetch user from localStorage (grab last signed-in user)
  const users = JSON.parse(localStorage.getItem('users')) || [];
  const currentUser = users[users.length - 1];

  const name = currentUser?.name || 'Friend';
  const children = currentUser?.children;
  const spouse = currentUser?.spouse;
  const caretaker = currentUser?.caretaker;
  const location = currentUser?.location || 'somewhere';

  let childText = children && children !== 'N/A' ? `Your kids are ${children}, ` : '';
  let spouseText = spouse && spouse !== 'N/A' ? `your partner is ${spouse}, ` : '';
  let caretakerText = caretaker && caretaker !== 'N/A' ? `your caretaker is ${caretaker}, ` : '';

  return (
    <div className={`dashboard-container ${isDay ? 'day-mode' : 'night-mode'}`}>
      <h2>Welcome to the Dashboard</h2>
      <p className="user-message">
        Hey {name}!, {childText}{spouseText}{caretakerText}you live in {location}.
      </p>

      <div className="button-group">
        <button onClick={() => navigate('/reminder')}>Reminders</button>
        <button onClick={() => navigate('/healthlog')}>Health Log</button>
        <button onClick={() => navigate('/calendar')}>Calendar</button>
        <button onClick={() => navigate('/login')}>Logout</button>
      </div>
    </div>
  );
}

export default Dashboard;
