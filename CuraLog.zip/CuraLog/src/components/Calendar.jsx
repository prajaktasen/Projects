import React, { useState, useEffect } from 'react';
import Calendar from 'react-calendar';
import 'react-calendar/dist/Calendar.css';
import './Calendar.css';
import { useNavigate } from 'react-router-dom';

function MyCalendar() {
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [appointments, setAppointments] = useState({});
  const [newAppointment, setNewAppointment] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    const stored = localStorage.getItem('appointments');
    if (stored) {
      setAppointments(JSON.parse(stored));
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('appointments', JSON.stringify(appointments));
  }, [appointments]);

  const handleAddAppointment = () => {
    const key = selectedDate.toDateString();
    const updated = {
      ...appointments,
      [key]: [...(appointments[key] || []), newAppointment],
    };
    setAppointments(updated);
    setNewAppointment('');
  };

  const tileContent = ({ date, view }) => {
    const key = date.toDateString();
    return view === 'month' && appointments[key] ? (
      <ul className="tile-tasks">
        {appointments[key].map((item, index) => (
          <li key={index}>{item}</li>
        ))}
      </ul>
    ) : null;
  };

  return (
    <div className="calendar-page">
      <button className="back-button" onClick={() => navigate('/dashboard')}>
        ← Return to Dashboard
      </button>

      <Calendar
        value={selectedDate}
        onClickDay={setSelectedDate}
        tileContent={tileContent}
      />

      <div className="appointment-form">
        <h3>Add Appointment for {selectedDate.toDateString()}</h3>
        <input
          type="text"
          placeholder="Appointment description"
          value={newAppointment}
          onChange={(e) => setNewAppointment(e.target.value)}
        />
        <button onClick={handleAddAppointment}>Add</button>
      </div>
    </div>
  );
}

export default MyCalendar;
