import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './Login.css';

function Login() {
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [message, setMessage] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();

    let storedUsers = localStorage.getItem('users');
    let users = [];
    try {
      users = storedUsers ? JSON.parse(storedUsers) : [];
      if (!Array.isArray(users)) users = [];
    } catch {
      users = [];
    }

    const matchedUser = users.find(
      (user) => user.email === email && user.password === password
    );

    if (matchedUser) {
      navigate('/dashboard');
    } else {
      setMessage('Incorrect email or password. Please try again.');
    }
  };

  return (
    <div className="create-account-container">
      <h2>Login</h2>
      <form onSubmit={handleSubmit} className="account-form">
        <label>
          Email
          <input
            type="email"
            placeholder="Enter your email"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
        </label>
        <label>
          Password
          <input
            type="password"
            placeholder="Enter your password"
            required
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </label>
        <button type="submit">Login</button>
      </form>
      {message && (
        <p style={{ color: '#ff9aa2', marginTop: '10px' }}>
          {message}
        </p>
      )}
      <p>
        Forgot your password?{' '}
        <span className="link" onClick={() => alert('Password reset coming soon.')}>
          Click here
        </span>
      </p>
      <p>
        Don’t have an account?{' '}
        <span className="link" onClick={() => navigate('/create-account')}>
          Create one
        </span>
      </p>
    </div>
  );
}

export default Login;
