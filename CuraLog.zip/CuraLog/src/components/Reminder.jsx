import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import './Reminder.css';

function Reminder() {
  const [message, setMessage] = useState('');
  const [time, setTime] = useState('');
  const [reminders, setReminders] = useState([]);
  const navigate = useNavigate();

  // Load reminders on component mount
  useEffect(() => {
    const stored = localStorage.getItem('reminders');
    if (stored) {
      try {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed)) {
          setReminders(parsed);
        }
      } catch (err) {
        console.error("Error loading reminders from localStorage", err);
      }
    }
  }, []);

  // Save to localStorage every time reminders change
  useEffect(() => {
    localStorage.setItem('reminders', JSON.stringify(reminders));
  }, [reminders]);

  // Notify if time matches
  useEffect(() => {
    if ('Notification' in window && Notification.permission !== 'granted') {
      Notification.requestPermission();
    }

    const interval = setInterval(() => {
      const now = new Date();
      setReminders(prev =>
        prev.map(r => {
          const rTime = new Date(r.time);
          if (!r.notified && rTime <= now && Notification.permission === 'granted') {
            new Notification("Reminder", { body: r.message });
            return { ...r, notified: true };
          }
          return r;
        })
      );
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  const handleAddReminder = () => {
    if (!message.trim() || !time) return;

    const newReminder = {
      message,
      time,
      notified: false
    };

    const updatedReminders = [...reminders, newReminder];
    setReminders(updatedReminders);
    setMessage('');
    setTime('');
  };

  return (
    <div className="reminder-container">
      <button onClick={() => navigate('/dashboard')} className="back-button">
        ← Return to Dashboard
      </button>
      <h2>Today's Reminders</h2>

      <div className="reminder-inputs">
        <input
          type="text"
          placeholder="Reminder message"
          value={message}
          onChange={e => setMessage(e.target.value)}
        />
        <input
          type="datetime-local"
          value={time}
          onChange={e => setTime(e.target.value)}
        />
        <button onClick={handleAddReminder}>Add</button>
      </div>

      <div className="reminder-list">
        {reminders.length === 0 ? (
          <p style={{ color: 'white' }}>No reminders added yet.</p>
        ) : (
          reminders.map((r, i) => (
            <div className="reminder-box" key={i}>
              <strong>{r.message}</strong><br />
              <span>{new Date(r.time).toLocaleString()}</span>
            </div>
          ))
        )}
      </div>
    </div>
  );
}

export default Reminder;
