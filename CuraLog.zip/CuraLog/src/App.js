import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import CreateAccount from './components/CreateAccount';
import Login from './components/Login';
import Dashboard from './components/Dashboard';
import Reminder from './components/Reminder';
import HealthLog from './components/HealthLog';
import Calendar from './components/Calendar';

import './App.css';

function App() {
  const hour = new Date().getHours();
  const isDay = hour >= 6 && hour < 18; // 6am–6pm is daytime

  return (
    <div className={`app-container ${isDay ? 'day' : 'night'}`}>
      <Router>
        <Routes>
          <Route path="/" element={<Navigate to="/create-account" />} />
          <Route path="/create-account" element={<CreateAccount />} />
          <Route path="/login" element={<Login />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/reminder" element={<Reminder />} />
          <Route path="/healthlog" element={<HealthLog />} />
          <Route path="/calendar" element={<Calendar />} />
        </Routes>
      </Router>
    </div>
  );
}

export default App;
