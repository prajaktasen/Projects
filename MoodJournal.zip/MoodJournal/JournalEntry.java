import java.time.LocalDate;

public class JournalEntry {
    private LocalDate date;
    private Mood mood;
    private String note;

    public JournalEntry(LocalDate date, Mood mood, String note) {
        this.date = date;
        this.mood = mood;
        this.note = note;
    }

    public Mood getMood() {
        return mood;
    }

    public String toString() {
        return String.format("[%s] Mood: %s\nEntry: %s\n", date.toString(), mood.name(), note);
    }
}
