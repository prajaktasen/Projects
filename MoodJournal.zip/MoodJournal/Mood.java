public enum Mood {
    HAPPY, SAD, ANXIOUS, NEUTRAL
}
