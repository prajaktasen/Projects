import java.util.Scanner;
import java.time.LocalDate;

public class MoodJournal {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        MoodTracker tracker = new MoodTracker();

        while (true) {
            System.out.println("\n=== Mood Journal ===");
            System.out.println("1. Log today's mood");
            System.out.println("2. View past entries");
            System.out.println("3. Mood summary");
            System.out.println("4. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // consume newline

            switch (choice) {
                case 1:
                    System.out.print("How are you feeling today (Happy, Sad, Anxious, Neutral): ");
                    String moodStr = scanner.nextLine().trim();
                    Mood mood = Mood.valueOf(moodStr.toUpperCase());

                    System.out.print("Write a short journal entry: ");
                    String note = scanner.nextLine();

                    JournalEntry entry = new JournalEntry(LocalDate.now(), mood, note);
                    tracker.addEntry(entry);
                    System.out.println("Mood logged successfully!");
                    break;

                case 2:
                    tracker.viewEntries();
                    break;

                case 3:
                    tracker.printSummary();
                    break;

                case 4:
                    System.out.println("Goodbye!");
                    return;

                default:
                    System.out.println("Invalid choice.");
            }
        }
    }
}
