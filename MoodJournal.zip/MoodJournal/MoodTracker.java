import java.util.ArrayList;
import java.util.HashMap;

public class MoodTracker {
    private ArrayList<JournalEntry> entries;

    public MoodTracker() {
        entries = new ArrayList<>();
    }

    public void addEntry(JournalEntry entry) {
        entries.add(entry);
    }

    public void viewEntries() {
        if (entries.isEmpty()) {
            System.out.println("No entries logged yet.");
        } else {
            for (JournalEntry entry : entries) {
                System.out.println(entry);
            }
        }
    }

    public void printSummary() {
        if (entries.isEmpty()) {
            System.out.println("No data to summarize.");
            return;
        }

        HashMap<Mood, Integer> countMap = new HashMap<>();
        for (Mood mood : Mood.values()) {
            countMap.put(mood, 0);
        }

        for (JournalEntry entry : entries) {
            countMap.put(entry.getMood(), countMap.get(entry.getMood()) + 1);
        }

        System.out.println("\nMood Summary:");
        for (Mood mood : Mood.values()) {
            System.out.printf("%s: %d\n", mood.name(), countMap.get(mood));
        }
    }
}
